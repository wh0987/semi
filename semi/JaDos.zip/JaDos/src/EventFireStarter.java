 public class EventFireStarter {
	 public static void main(String[] args) {
	  new EventFireGui();
	 }
	}